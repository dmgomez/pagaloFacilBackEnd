$( "#ultimos" ).on( "click", ".ultimos-cinco", function() {
  	$('#sample_search').val($(this).attr('id'));
  	$("#sample_search").focusin();
});

$( "#favoritos" ).on( "click", ".cliente-favorito", function() {
  	$('#sample_search').val($(this).attr('id'));
  	$("#sample_search").focusin();
});


$(document).ready(function() {

	//-------------------------------cargar-ultimos-5-----------------------------------------------------
	$.ajax({
	    url: "services/ServicioUsuario.php",
	    type: "POST",
	    data: {
	        accion: "cargarUltimosCinco"
	    },
	    dataType: 'json',
	    success: function(data){  
         
         	//console.log(data);
         	if (data.success) {

         		$('#ultimos').html(data.clientes);	
         	}
         	else {

         		$('#ultimos').html('&emsp;<i>No se encontró ningún registro</i>');
         	}
         	
     	}

    });

	//-------------------------------fin-cargar-ultimos-5-------------------------------------------------

	//-------------------------------cargar-favoritos-----------------------------------------------------
	$.ajax({
	    url: "services/ServicioUsuario.php",
	    type: "POST",
	    data: {
	        accion: "cargarFavoritos"
	    },
	    dataType: 'json',
	    success: function(data){  
         
         	//console.log(data);
         	if (data.success) {

         		$('#favoritos').html(data.clientes);	
         	}
         	else {

         		$('#favoritos').html('&emsp;<i>No se encontró ningún registro</i>');
         	}
         	
     	}

    });

	//-------------------------------fin-cargar-favoritos-------------------------------------------------

});