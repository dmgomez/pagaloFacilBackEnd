<?php
header("Access-Control-Allow-Origin: *");
include_once '../database/Connection.php';

if(!isset($_POST['payment'])){
    exit(-1);
}

extract($_POST['payment']);

$ch = curl_init();
$url = 'https://api.instapago.com/payment';

curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_USERAGENT,'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Ubuntu Chromium/32.0.1700.107 Chrome/32.0.1700.107 Safari/537.36');
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS,
    "KeyId=D414AEA3-DBF7-443E-9E0F-DC669D99D544"
    . "&PublicKeyId=e475d9510184b4f73e3b7a2e508e759a"
    . "&Amount=$amount"
    . "&Description=$description"
    . "&CardHolder=$cardHolder"
    . "&CardHolderID=$cardHolderID"
    . "&CardNumber=$cardNumber"
    . "&CVC=$cvc"
    . "&ExpirationDate=$expirationDateMonth/$expirationDateYear"
    . "&StatusId=1"

);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_COOKIESESSION, true);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER,false);

$answer = curl_exec($ch);

if (curl_error($ch)) {
    echo 'Ocurrio un error inesperado: '.curl_error($ch);
    die;
}
else{
    //echo "ENTRAAAAA";
    //correo
    $correo="NADA";
    $user_mail=$_POST['user'];
    $conn = new PDO("mysql:host=$servername;dbname=$database", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    //echo "CONSULTA SELECT correo FROM cliente WHERE cedula = ".$user_mail;
    $usuario = $conn->prepare("SELECT * FROM cliente WHERE cedula = '".$user_mail."'");
   // $usuario = $conn->prepare("SELECT * FROM cliente");

    //$usuario->bindParam(':cedula',$user_mail);

    $usuario->execute();

    $result = $usuario->fetch(PDO::FETCH_ASSOC);
     //echo $result['cedula'];
    if(!count($result)){

        $correo = false;
        //echo "CORREO: NO";
    }
    else{
        $correo = $result['correo'];
        //echo  "CORREO: ".$result['correo'];
        //print_r($result);
    }

                        $mail = "Has recibido un pago a través de nuestra plataforma :
                        Monto:$amount bsf
                        Esta solicitud será procesada por nosotros y se acreditará en su cuenta asociada";

                        //Titulo
                        $titulo = "Pago recibido";
                        //cabecera
                        $headers = "MIME-Version: 1.0\r\n"; 
                        $headers .= "Content-type: text/html; charset=iso-8859-1\r\n"; 
                        //dirección del remitente 
                        $headers .= "From: PagaloFacil < support@pagalofacil.com >\r\n";
                        //Enviamos el mensaje a tu_dirección_email 
                        $bool = mail($correo,$titulo,$mail,$headers);
                       

}

echo $answer;
?>