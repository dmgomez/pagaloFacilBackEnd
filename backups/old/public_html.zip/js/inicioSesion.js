$('#btnAceptar').on('click', function(e) {
  var user = $("#user").val();
  var pssw = $("#password").val();

  $.ajax({   
    url: "https://pagalofacil.com/services/ServicioUsuario.php",
    type: "POST",
    data: {accion: "iniciarSesion", user: user, pssw: pssw},
    dataType: 'json',
    success: function(data){  
      //console.log(data);
       //e.preventDefault();
      if(data.success)
      {
        if(data.flag)
        {
          window.location="https://pagalofacil.com/index.html";
        }
        else
        {
          Materialize.toast("Usuario o contraseña incorrecto", 4000); 
        }
        
      }
      else
      {
        alert(data.message);   
       // e.preventDefault();
      }
    }
  });
}); 