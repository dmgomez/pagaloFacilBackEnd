<?php
header("Access-Control-Allow-Origin: *");
include_once '../database/Connection.php';

session_start();

if(!isset($_SESSION['usuario_sistema_id_usuario'],$_SESSION['usuario_sistema_nombre'],$_SESSION['usuario_sistema_rol'])){
    echo json_encode(['success' => false, 'message' => 'Error, no tienes permisos para acceder a &eacute;sta secci&oacute;n','data'=>[0,1,2,3,4,5,6,7]]);
    return;
}

if (isset($_POST["accion"])) {

    $result = array('success' => true);

    switch ($_POST["accion"]) {
        case "listarTransacciones":
            try {
                $conn = new PDO("mysql:host=$servername;dbname=$database", $username, $password);
                // set the PDO error mode to exception
                $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                $listado_trans = $conn->prepare("SELECT tr.id_transaccion as id, CONCAT(em.nombre,\" \",em.apellido) as emisor,CONCAT(rc.nombre,\" \",rc.apellido) as receptor,
                                                   tr.monto_transaccion as cantidad, rc.numero_cuenta as numero_de_cuenta, tr.fecha as fecha,
                                                   COALESCE(sts.estado,'Pendiente') AS estado,'EDIT_BTN' AS edit_btn
                                                    FROM transaccion AS tr
                                                      LEFT JOIN cliente em ON tr.emisor_id = em.id_cliente
                                                      LEFT JOIN cliente rc ON tr.receptor_id = rc.id_cliente
                                                      LEFT JOIN (SELECT g3.id_transaccion  AS tra, g3.id_gestion, g3.estatus_gestion AS lst
                                                                 FROM gestion AS g3
                                                                   INNER JOIN (SELECT
                                                                                 g.id_transaccion  AS tra,
                                                                                 MAX(g.id_gestion) AS mid
                                                                               FROM gestion g
                                                                               GROUP BY g.id_transaccion) AS g2 ON g2.mid = g3.id_gestion
                                                                     ) AS gest ON tr.id_transaccion = gest.tra
                                                      LEFT JOIN status sts ON gest.lst = sts.id_status
                                                    
                                                    ORDER BY tr.fecha");
                $listado_trans->execute(); 

                $result_trans = $listado_trans->fetchAll(PDO::FETCH_NUM);

                $result = array('success' => true, 'data' => $result_trans);

                $conn = null;
            } catch (PDOException $e) {
                $result = array('success' => false, 'message' => "Error: " . $e->getMessage());
            }

            break;
        case "listarGestiones":
            try {
                $conn = new PDO("mysql:host=$servername;dbname=$database", $username, $password);
                // set the PDO error mode to exception
                $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                $listado_gest = $conn->prepare("SELECT gestion.id_gestion, gestion.nota_gestion, gestion.fecha_gestion, status.estado
                                                FROM gestion
                                                LEFT JOIN status ON gestion.estatus_gestion = status.id_status
                                                WHERE gestion.id_transaccion = :id_transaccion ORDER BY id_gestion DESC");
                $listado_gest->bindParam(':id_transaccion', $_POST['transaccion_id']);
                $listado_gest->execute();

                $result_gest = $listado_gest->fetchAll(PDO::FETCH_ASSOC);

                $result = array('success' => true, 'data' => $result_gest);

                $conn = null;
            } catch (PDOException $e) {
                $result = array('success' => false, 'message' => "Error: " . $e->getMessage());
            }
         break;
        case "insertarGestion":
            try {
                $conn = new PDO("mysql:host=$servername;dbname=$database", $username, $password);
                // set the PDO error mode to exception
                $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                $gestion = $conn->prepare("INSERT gestion (id_transaccion,nota_gestion, estatus_gestion,usuario_id_usuario) 
                                    VALUES (:id_transaccion,:nota_gestion,:estatus_gestion,:usuario_id_usuario)");
                $gestion->bindParam(':id_transaccion', $_POST['id_transaccion']);
                $gestion->bindParam(':nota_gestion', $_POST['nota_gestion']);
                $gestion->bindParam(':estatus_gestion', $_POST['estatus_gestion']);
                $gestion->bindParam(':usuario_id_usuario',$_SESSION['usuario_sistema_id_usuario']);
                $gestion->execute();


                $conn = null;
            } catch (PDOException $e) {
                $result = array('success' => false, 'message' => "Error: " . $e->getMessage());
            }
         break;
        case "listarAdminUsers":
            try {
                $conn = new PDO("mysql:host=$servername;dbname=$database", $username, $password);
                // set the PDO error mode to exception
                $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                $listado_adm = $conn->prepare("SELECT us.id_usuario AS id, us.username AS username, CONCAT(us.nombre,\" \",us.apellido) AS nombre, us.correo AS correo,
                                                        case us.rol WHEN 1 THEN 'Super Administrador' WHEN 2 THEN 'Administrador' END AS rol, us.fecha_creacion as fecha
                                                FROM
                                                  usuario_sistema AS us
                                                WHERE us.is_delete = 0 AND us.id_usuario <> {$_SESSION['usuario_sistema_id_usuario']}
                                                ORDER BY us.fecha_creacion");
                $listado_adm->execute();

                $result_adm = $listado_adm->fetchAll(PDO::FETCH_NUM);

                $result = array('success' => true, 'data' => $result_adm);

                $conn = null;
            } catch (PDOException $e) {
                $result = array('success' => false, 'message' => "Error: " . $e->getMessage());
            }
            break;
        case "eliminarAdminUsers":
            try {
                $conn = new PDO("mysql:host=$servername;dbname=$database", $username, $password);
                // set the PDO error mode to exception
                $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                $elim_adm = $conn->prepare("UPDATE usuario_sistema
                                            SET is_delete = 1
                                            WHERE usuario_sistema.id_usuario = :id_usuario");
                $elim_adm->bindParam(':id_usuario', $_POST['id_usuario']);
                $elim_adm->execute();

                $result = array('success' => true);

                $conn = null;
            } catch (PDOException $e) {
                $result = array('success' => false, 'message' => "Error: " . $e->getMessage());
            }
            break;
    }
}
else
{
    $result = array('success' => false, 'message' => "Acción no definida");
}

echo json_encode($result);