<?php
    $servername = "108.167.189.74";
    $database = "lotica_pagalofacil";
    $username = "lotica_dev";
    $password = "a123456";